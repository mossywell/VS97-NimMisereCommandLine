// File name: General.h
// Contains my general #defines


// Define stuff
#define OK 0
#define NOMEMORY 99
#define TRUE 1
#define FALSE 0
#define BADINPUT 25
#define GENERALERROR 255

typedef unsigned int uint;
